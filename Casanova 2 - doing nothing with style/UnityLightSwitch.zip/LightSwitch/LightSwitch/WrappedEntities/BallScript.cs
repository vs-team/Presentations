﻿using UnityEngine;
using System.Collections;
public class UnityBall : MonoBehaviour
{
  public Vector3 Position { get { return this.transform.position; } set { this.transform.position = value; } }
  bool destroyed = false;
  public bool Destroyed { get { return destroyed; } set { destroyed = value; if (value) UnityEngine.Object.Destroy(this.gameObject); } }
  static Random random = new Random();
  public bool Visible { get { return this.renderer.isVisible; } }
  public Color Color { get { return this.renderer.material.color; } set { this.renderer.material.color = value; } }
  static public UnityBall Create()
  {
    var position = new Vector3(UnityEngine.Random.Range(25, 40), UnityEngine.Random.Range(-9, -15), -48);

    var ball = UnityEngine.Object.Instantiate(Resources.Load("Sphere"), position, Quaternion.identity) as GameObject;
    return ball.GetComponent<UnityBall>();
  }

}
