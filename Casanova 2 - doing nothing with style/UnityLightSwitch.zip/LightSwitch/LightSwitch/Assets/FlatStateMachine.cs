﻿using UnityEngine;
using System.Collections;

public class FlatStateMachine : MonoBehaviour {
    bool state;
    bool previousInput;

	// Use this for initialization
	void Start () {
	
	}

    void UpdateLight(bool s) {
        renderer.material.color = s ? new Color(0, 0, 0) : new Color(1, 1, 1);
    }
	
	// Update is called once per frame
	void Update () {
        bool currentInput = Input.GetMouseButton(0);
        if (!previousInput && currentInput) {
            state = !state;
            UpdateLight(state);
        }
        previousInput = currentInput;
	}
}
