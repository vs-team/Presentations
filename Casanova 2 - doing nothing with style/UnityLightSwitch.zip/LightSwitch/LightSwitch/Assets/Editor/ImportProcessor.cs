﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Diagnostics;
using System.Linq;
using System.IO;
using System.Collections.Generic;
using System.Text;


public class AssetsImport : AssetPostprocessor
{
  static AssetsImport Singleton = new AssetsImport();

  static void SystemCall(string cmd, string args)
  {
    try
    {
      Process myProcess = new Process();
      myProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
      myProcess.StartInfo.CreateNoWindow = true;
      myProcess.StartInfo.FileName = cmd;
      myProcess.StartInfo.Arguments = args;
      myProcess.EnableRaisingEvents = true;
      myProcess.StartInfo.UseShellExecute = false;
      myProcess.StartInfo.RedirectStandardOutput = true;
      myProcess.StartInfo.RedirectStandardError = true;

      var process = Process.Start(myProcess.StartInfo);

      bool isDone1 = false;
      var redirectStandardOutput = new System.Threading.Thread(() =>
        {
          string str;
          while ((str = process.StandardOutput.ReadLine()) != null)
          {
            UnityEngine.Debug.Log(str);
          }
          isDone1 = true;
        });
      redirectStandardOutput.IsBackground = true;
      redirectStandardOutput.Start();

      bool isDone2 = false;
      System.Threading.Thread redirectStandardError = new System.Threading.Thread(() =>
      {
        string error;
        while ((error = process.StandardError.ReadLine()) != null)
        {
          if (error.Contains("error"))
            Singleton.LogError(error);
          else
            UnityEngine.Debug.Log(error);
        }
        isDone2 = true;
      });
      redirectStandardError.IsBackground = true;
      redirectStandardError.Start();

      process.WaitForExit();
      while (!isDone1 || !isDone2) { }
    }
    catch (System.Exception e)
    {
      UnityEngine.Debug.Log(e);
    }
  }

  static void CasanovaCompile(string fileName)
  {
    string args = "Assets\\" + fileName + ".cnvproj -o:Assets\\" + fileName + ".dll " +
          "--target:library -g --standalone --debug:full --noframework --define:DEBUG --define:TRACE --optimize- --tailcalls- --platform:x64 " +
          "--target:library --warn:3 --warnaserror:76 --vserrors --validate-type-providers --LCID:1033 --utf8output --fullpaths --flaterrors " +
          "--highentropyva- -r:CasanovaCompiler\\UnityEngine.dll -r:CasanovaCompiler\\CasanovaPrelude.dll -r:libs\\FSharp.Core.dll " +
          "-r:libs\\mscorlib.dll -r:Assets\\WrappedEntities.dll";


    SystemCall("CasanovaCompiler\\fsc.exe", args);
  }

  static IEnumerable<string> ProjectChildren(string project)
  {
    foreach (string line in File.ReadAllLines(project))
    {
      if (line.StartsWith("import"))
      {
        string file = line.Replace("import ", "").Trim(new[] { ' ', '\"' });
        yield return System.IO.Path.GetFullPath(System.IO.Path.Combine("Assets", file));
      }
    }
  }

  static void OnPostprocessAllAssets(string[] importedAssets, string[] deletedAssets, string[] movedAssets, string[] movedFromAssetPaths)
  {
    Dictionary<string, bool> projectsToBuild = new Dictionary<string, bool>();
    foreach (string asset in importedAssets.Select(x => System.IO.Path.GetFullPath(x)))
    {
      if (asset.EndsWith(".cnv"))
      {
        foreach (var file in System.IO.Directory.GetFiles("Assets"))
        {
          if (file.EndsWith(".cnvproj"))
          {
            //UnityEngine.Debug.Log("Looking for project file in " + file);
            if (ProjectChildren(file).Contains(asset))
            {
              //UnityEngine.Debug.Log("Found!");
              if (!projectsToBuild.ContainsKey(System.IO.Path.GetFullPath(file)))
                projectsToBuild.Add(System.IO.Path.GetFullPath(file), true);
            }
          }
        }
      }

      if (asset.EndsWith(".cnvproj"))
      {
        if (!projectsToBuild.ContainsKey(System.IO.Path.GetFullPath(asset)))
          projectsToBuild.Add(System.IO.Path.GetFullPath(asset), true);
      }
    }
    foreach (var project in projectsToBuild)
    {
      CasanovaCompile(System.IO.Path.GetFileNameWithoutExtension(project.Key));
    }
  }
}
