﻿using UnityEngine;
using System.Collections;

public class FlatStateMachineFade : MonoBehaviour {
    float brightness;
    bool previousInput;
    bool state;

    // Use this for initialization
    void Start() {

    }

    void UpdateLight(float b) {
        renderer.material.color = new Color(b, b, b);
    }

    // Update is called once per frame
    void Update() {
        if (state) {
            brightness = Mathf.Clamp01(brightness + 0.02f);
        } else {
            brightness = Mathf.Clamp01(brightness - 0.02f);
        }
        bool currentInput = Input.GetMouseButton(0);
        if (!previousInput && currentInput) {
            state = !state;
        }
        previousInput = currentInput;
        UpdateLight(brightness);
    }
}
