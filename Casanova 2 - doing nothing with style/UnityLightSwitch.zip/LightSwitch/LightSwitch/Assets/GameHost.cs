﻿using UnityEngine;
using System.Collections;

public class GameHost : MonoBehaviour {
	Game.World game;
	// Use this for initialization
	void Start () {
    var A = transform.Find("/A").GetComponent<UnityBall>();
    var B = transform.Find("/B").GetComponent<UnityBall>();
    var C = transform.Find("/C").GetComponent<UnityBall>();
		game = Game.World.Create (A, B, C);
	}
	
	// Update is called once per frame
	void Update () {
		Game.update (game, Time.deltaTime);
	}
}
