﻿using UnityEngine;
using System.Collections;

public class Message : MonoBehaviour {
    bool state;

    void UpdateLight(bool s) {
        renderer.material.color = s ? new Color(0, 0, 0) : new Color(1, 1, 1);
    }
	
    // called when object clicked on
    void OnMouseDown() {
        state = !state;
        UpdateLight(state);
    }

}
