﻿using UnityEngine;
using System.Collections;

public class PollingTransition : MonoBehaviour {
    bool state;

    void UpdateLight(bool s) {
        renderer.material.color = s ? new Color(0, 0, 0) : new Color(1, 1, 1);
    }

    void Update() {
        if (Input.GetMouseButtonDown(0)) {
            state = !state;
            UpdateLight(state);
        }
    }
}
