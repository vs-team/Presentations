﻿using UnityEngine;
using System.Collections;

// switch between on, off and flash
public class FlatStateMachineModal : MonoBehaviour {
    float brightness;
    bool previousInput;
    int state;
    float onTime;
    float pauseTime;

    // Use this for initialization
    void Start() {

    }

    void UpdateLight(float b) {
        renderer.material.color = new Color(b, b, b);
    }

    // Update is called once per frame
    void Update() {
        switch (state) {
            case 0:
                // off
                UpdateLight(0);
                break;
            case 1:
                // on
                UpdateLight(1);
                break;
            case 2:
                // flash on
                UpdateLight(1);
                pauseTime=Time.time;
                state=4;
                break;
            case 3:
                // flash off
                UpdateLight(0);
                pauseTime=Time.time;
                state=5;
                break;
            case 4:
                // wait flash on
                if(Time.time-pauseTime > 0.5) {
                    state=3;
                }
                break;
            case 5:
                // wait flash off
                // wait flash on
                if(Time.time-pauseTime > 0.5) {
                    state=2;
                }
                break;
        }


        bool currentInput = Input.GetMouseButton(0);

        if (!previousInput && currentInput) {
            switch(state) {
                case 0:
                    state = 1;
                    break;
                case 1:
                    state = 2;
                    break;
                case 2:
                case 3:
                case 4:
                case 5:
                    state = 0;
                    break;
            }           
        }

        previousInput = currentInput;
    }
}
