﻿using UnityEngine;
using System.Collections;

public class FlatStateMachineModalFader : MonoBehaviour {

   float brightness=1;
    bool previousInput;
    int state;
    int newState;
    int nextState=-1; // hack for non interrtupable, -1 means don't switch
    float onTime;
    float pressTime;
    float pauseTime;

    // Use this for initialization
    void Start() {

    }

    void UpdateLight(float b) {
        renderer.material.color = new Color(b, b, b);
    }

    void SwitchState(int s) {
    }

    // Update is called once per frame
    void Update() {
        bool currentInput = Input.GetMouseButton(0);

        if (state != newState) {
            // allow initialisation on transitions between states
            switch (state) {
                default:
                switch(newState) {
                    case 2: // flash
                        brightness = 1;
                        break;
                    case 6: // Fade up, start with brightness of zero
                        brightness = 0;
                        break;
                }
                break;
            }
            state = newState;
        }

        switch (state) {
            case 0:
                // off
                UpdateLight(0);
                break;
            case 1:
                // on
                UpdateLight(1);
                break;
            case 2:
                // flash on
                UpdateLight(brightness);
                pauseTime = Time.time;
                newState = 4;
                break;
            case 3:
                // flash off
                UpdateLight(0);
                pauseTime = Time.time;
                newState = 5;
                break;
            case 4:
                // wait flash on
                // (non interruptable)
                if (Time.time - pauseTime > 2.0f/3.0f) {
                    if (nextState != -1) {
                        newState = nextState;
                        nextState = -1;
                    } else {
                        newState = 3;
                    }
                }
                break;
            case 5:
                // wait flash off
                // wait flash on
                if (Time.time - pauseTime > 1.0f/3.0f) {
                    newState = 2;
                }
                break;
            case 6:
                // Fade up
                brightness = Mathf.Clamp01(brightness + 0.005f);
                UpdateLight(brightness);
                if (brightness >= 1.0f) {
                    newState = 7;
                }
                break;
            case 7:
                // do nothing
                break;
            case 8:
                // sine wave
                brightness = 0.5f + Mathf.Sin(2*(Time.time - onTime)) * 0.5f;
                UpdateLight(brightness);
                break;
        }

        // check if button held down 2 seconds
        if (pressTime > 0 && currentInput && Time.time - pressTime > 2) {
            newState = 8; // sine save
        }
        // cancell hold down time if button released
        if (!currentInput) {
            pressTime = 0;
        }


        // when button pressed
        if (!previousInput && currentInput) {
            pressTime = Time.time;
            switch (state) {
                case 0:
                    newState = 1;
                    break;
                case 1:
                    newState = 2;
                    break;
                case 4:
                    // wait for flash on
                    // non interruptable so can't just switch state
                    nextState = 6;
                    break;
                case 2:
                case 3:
                case 5:
                    newState = 6;
                    break;
                case 6:
                    newState = 7;
                    break;
                case 7:
                    newState = 0;
                    break;
                case 8:
                    newState = 0;
                    break;
            }
        }

        previousInput = currentInput;
    }
}
